package com.example.test1_sergiopereira_766570;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class WelcomePage extends AppCompatActivity implements View.OnClickListener, AdapterView.OnItemSelectedListener {
    TextView studentName, fee, hour, totalFees, totalHours;
    Button addBtn;
    RadioGroup radioGroup;
    RadioButton graduatedRBtn, ungraduatedRBtn;

    Spinner spinner;

    String courses[] = {"Java", "Swift", "iOS", "Android", "Database"};
    Integer fees[] = {1300, 1500, 1350, 1400, 1000};
    Integer hours[] = {6, 5, 5, 7, 4};

    int totalF = 0;
    int totalH = 0;
    int varFee, varHour;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_page);

        studentName = findViewById(R.id.studentName);
        studentName.setText("Welcome, " + MainActivity.name);

        fee = findViewById(R.id.fee);
        hour = findViewById(R.id.hour);
        totalFees = findViewById(R.id.totalFees);
        totalHours = findViewById(R.id.totalHours);

        addBtn = findViewById(R.id.addBtn);
        addBtn.setOnClickListener(this);

        radioGroup = findViewById(R.id.radioGroup);

        graduatedRBtn = findViewById(R.id.graduatedRBtn);
        ungraduatedRBtn = findViewById(R.id.ungraduatedRBtn);
        graduatedRBtn.setOnClickListener(this);
        ungraduatedRBtn.setOnClickListener(this);

        spinner = findViewById(R.id.spinner);
        ArrayAdapter<String> coursesArr = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_dropdown_item, courses);
        spinner.setAdapter(coursesArr);

        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onClick(View v) {
        if (v.getId() == R.id.addBtn) {
            if (graduatedRBtn.isChecked()) {
                totalF += varFee;
                totalH += varHour;

                if (totalH <= 21) {
                    totalFees.setText("Total Fees: CA$" + totalF);
                    totalHours.setText("Total Hours: " + totalH);
                } else {
                    totalF -= varFee;
                    totalH -= varHour;
                    Toast.makeText(getApplicationContext(), "You cannot have more than 21 hours/week.", Toast.LENGTH_LONG).show();
                }
            } else if (ungraduatedRBtn.isChecked()){
                totalF += varFee;
                totalH += varHour;
                if (totalH <= 19) {
                    totalFees.setText("Total Fees: CA$" + totalF);
                    totalHours.setText("Total Hours: " + totalH);
                } else {
                    totalF -= varFee;
                    totalH -= varHour;
                    Toast.makeText(getApplicationContext(), "You cannot have more than 21 hours/week.", Toast.LENGTH_LONG).show();
                }
            }

        }

        else if (v.getId() == R.id.graduatedRBtn) {
                totalHours.setText("");
                totalFees.setText("");
                totalF = 0;
                totalH = 0;
        } else if (v.getId() == R.id.ungraduatedRBtn) {
                totalHours.setText("");
                totalFees.setText("");
                totalF = 0;
                totalH = 0;

        }

    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View adapterView, int position, long id) {

        fee.setText(fees[position].toString());
        hour.setText(hours[position].toString());

        varFee = fees[position];
        varHour = hours[position];
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {

    }
}