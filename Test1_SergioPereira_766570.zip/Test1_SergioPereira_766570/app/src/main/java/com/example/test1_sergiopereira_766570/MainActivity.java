package com.example.test1_sergiopereira_766570;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    EditText usernameInput, passwordInput, nameInput;
    Button loginBtn;
    public static String name;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        usernameInput = findViewById(R.id.usernameInput);
        passwordInput = findViewById(R.id.passwordInput);
        nameInput = findViewById(R.id.nameInput);

        loginBtn = findViewById(R.id.loginBtn);

        loginBtn.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        Intent toWelcomePage = new Intent(MainActivity.this, WelcomePage.class);

        String password = passwordInput.getText().toString();
        String username = usernameInput.getText().toString();
        String studentName = nameInput.getText().toString();

        if (username.equalsIgnoreCase("student1")){
            if (password.equals("123456")) {
                if (!studentName.isEmpty()) {
                    name = studentName;
                    startActivity(toWelcomePage);
                }else {
                    Toast.makeText(getApplicationContext(), "Enter your name", Toast.LENGTH_LONG).show();
                }
            }else {
                Toast.makeText(getApplicationContext(), "Invalid password", Toast.LENGTH_LONG).show();
            }
        }else {
            Toast.makeText(getApplicationContext(), "Invalid username", Toast.LENGTH_LONG).show();
        }

        nameInput.setText("");
        usernameInput.setText("");
        passwordInput.setText("");
    }
}